package edu.uncw.seahawktours;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        boolean spinaroo = true;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<String> buildings = new ArrayList<>();
        buildings.add(String.valueOf(getText(R.string.cis)));
        buildings.add(String.valueOf(getText(R.string.os)));
        buildings.add(String.valueOf(getText(R.string.br)));

        Spinner s = findViewById(R.id.spin);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, buildings);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);

        if (spinaroo) {
            findViewById(R.id.brButton).setVisibility(View.GONE);
            findViewById(R.id.osButton).setVisibility(View.GONE);
            findViewById(R.id.cisButton).setVisibility(View.GONE);
        } else {
            findViewById(R.id.spin).setVisibility(View.GONE);
            findViewById(R.id.spinButton).setVisibility(View.GONE);
        }
    }

    public void onClickCIS(View view) {
        String messageText = getString(R.string.cisHistory);
        String titleText = getString(R.string.cisTitle);
        String image = "cis1";

        Intent intent = new Intent(this, DetailActivity.class);
        Bundle extras = new Bundle();
        extras.putString(DetailActivity.EXTRA_MESSAGE, messageText);
        extras.putString(DetailActivity.EXTRA_TITLE, titleText);
        extras.putString(DetailActivity.EXTRA_IMAGE, image);
        intent.putExtras(extras);
        startActivity(intent);
    }

    public void onClickOS(View view) {
        String messageText = getString(R.string.rlHistory);
        String titleText = getString(R.string.rlTitle);
        String image = "library";

        Intent intent = new Intent(this, DetailActivity.class);
        Bundle extras = new Bundle();
        extras.putString(DetailActivity.EXTRA_MESSAGE, messageText);
        extras.putString(DetailActivity.EXTRA_TITLE, titleText);
        extras.putString(DetailActivity.EXTRA_IMAGE, image);
        intent.putExtras(extras);
        startActivity(intent);
    }

    public void onClickBR(View view) {
        String messageText = getString(R.string.brHistory);
        String titleText = getString(R.string.brTitle);
        String image = "oldbear";

        Intent intent = new Intent(this, DetailActivity.class);
        Bundle extras = new Bundle();
        extras.putString(DetailActivity.EXTRA_MESSAGE, messageText);
        extras.putString(DetailActivity.EXTRA_TITLE, titleText);
        extras.putString(DetailActivity.EXTRA_IMAGE, image);
        intent.putExtras(extras);
        startActivity(intent);
    }

    public void onClickSpin(View view) {
        Spinner s = findViewById(R.id.spin);
        String selected = s.getSelectedItem().toString();
        if (selected.equals(String.valueOf(getText(R.string.cis)))) {
            onClickCIS(findViewById(R.id.spin));
        }
        if (selected.equals(String.valueOf(getText(R.string.br)))) {
            onClickBR(findViewById(R.id.spin));
        }
        if (selected.equals(String.valueOf(getText(R.string.os)))) {
            onClickOS(findViewById(R.id.spin));
        }
    }
}
