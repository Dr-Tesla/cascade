package edu.uncw.seahawktours;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DetailActivity extends Activity {

    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_TITLE = "title";
    //image location
    public static final String EXTRA_IMAGE = "image";

    String messageText;
    String titleText;
    int imageId;

    private Boolean debugB = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        if (savedInstanceState != null) {
            messageText = savedInstanceState.getString("message");
            titleText = savedInstanceState.getString("title");
            imageId = savedInstanceState.getInt("image");
        }

        Intent intent = getIntent();

        ImageView iv = findViewById(R.id.iv);

        messageText = intent.getStringExtra(EXTRA_MESSAGE);
        TextView messageView = findViewById(R.id.message);
        messageView.setText(messageText);

        titleText = intent.getStringExtra(EXTRA_TITLE);
        TextView titleView = findViewById(R.id.title);
        titleView.setText(titleText);

        String image = (intent.getStringExtra(EXTRA_IMAGE));

        int id = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
        String debug = Integer.toString(id);
        iv.setImageResource(id);

        if (debugB)
            popDebug(this, debug);

    }


    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString("message", messageText);
        savedInstanceState.putString("title", titleText);
        savedInstanceState.putInt("image", imageId);
    }

    public static void popDebug(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

}
